import json
import boto3
import uuid

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('event-data-table')

def lambda_handler(event, context):
    for record in event.get('Records', []):
        body = record.get('body', '{}')
        data = json.loads(body)

        table.put_item(
            Item={
                'id': str(uuid.uuid4()),
                'eventType': data.get('eventType', 'unknown'),
                'timestamp': data.get('timestamp', 'unknown')
            }
        )

    return {
        'statusCode': 200,
        'body': 'Event processed successfully'
    }
